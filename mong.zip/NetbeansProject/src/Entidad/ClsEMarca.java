/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Entidad;

/**
 *
 * @author Arnold
 */
public class ClsEMarca {

    public int getId_marca() {
        return Id_marca;
    }

    public void setId_marca(int Id_marca) {
        this.Id_marca = Id_marca;
    }

    public String getNombre_marca() {
        return Nombre_marca;
    }

    public void setNombre_marca(String Nombre_marca) {
        this.Nombre_marca = Nombre_marca;
    }
    
    
    private int Id_marca;
    private String Nombre_marca;
}
