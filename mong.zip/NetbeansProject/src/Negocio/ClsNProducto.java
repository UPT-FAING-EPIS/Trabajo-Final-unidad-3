/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Negocio;

import Entidad.ClsEProducto;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;

import Negocio.*;
import java.sql.PreparedStatement;
import java.util.Vector;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JComboBox;
import Entidad.ClsECategoria;
import Entidad.ClsEEmpleado;

/**
 *
 * @author Arnold
 */
public class ClsNProducto {
    
    
    public void Mtd_listar_producto(JComboBox box, int id){
        
        DefaultComboBoxModel value;
        Connection con=(Connection) ClsConexion.Conectar();
        PreparedStatement ps = null;
        ResultSet rs = null;
        try{
            ps = con.prepareStatement("SELECT * from producto where Categoria_id = ?;");
            ps.setInt(1, id);
            rs = ps.executeQuery();
            value = new DefaultComboBoxModel();
            box.setModel(value);
            while(rs.next()){
                value.addElement(new ClsEProducto(rs.getInt(1),rs.getString(2),rs.getString(3),rs.getInt(4),rs.getDouble(5)));
            }
        }catch(Exception ex){
            System.out.println(ex.getMessage());
        }finally{
            try{
                ps.close();
                rs.close();
                con.close();
            }catch(Exception ex){
            }
        }
        
    }
    
    public void Mtd_Sin_Categoria(JComboBox box){
        
        DefaultComboBoxModel value;
        value = new DefaultComboBoxModel();
        value.addElement("seleccione una categoria");
        box.setModel(value);
 
    }
    
    public boolean MtdRegistrarProducto(ClsEProducto objEProd) {
      PreparedStatement ps=null;      
      Connection con=(Connection) ClsConexion.Conectar();
      String sql="Insert into producto (id,nombre,Marca_id,stock,precio_venta,precio_compra,stock_referencial,Categoria_id,dni_empleado_mongo,estado) values(?,?,?,?,?,?,?,?,?,'A'); ";
            try {
            ps=con.prepareStatement(sql);
            ps.setInt(1,objEProd.getId());
            ps.setString(2,objEProd.getNombre());
            ps.setString(3,objEProd.getMarca()); 
            ps.setInt(4,objEProd.getStock());
            ps.setDouble(5,objEProd.getPrecio_venta());
            ps.setDouble(6,objEProd.getPrecio_compra());
            ps.setInt(7,objEProd.getStockReferencial());
            ps.setInt(8,objEProd.getCategoria_id());
            ps.setInt(9,objEProd.getDni_Empleado());
            ps.executeUpdate();//permite actualizar 
            return true;
            }            
         catch (Exception e) {
             System.err.println(""+e);
            return false;
        }
    
    }
    
}

