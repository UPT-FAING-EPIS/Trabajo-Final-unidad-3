/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Negocio;

import com.mongodb.BasicDBObject;
import com.mongodb.DB;
import com.mongodb.DBCollection;
import com.mongodb.DBCursor;
import com.mongodb.MongoClient;
import com.mongodb.MongoException;
import java.util.List;
import javax.swing.JOptionPane;


import java.util.logging.Level;
import java.util.logging.Logger;


/**
 *
 * @author Rafael
 */
public class ClsConexionMongo {
    public DB db;
    public DBCollection tabla;
    public DBCursor cursos=null;
    public BasicDBObject document=new BasicDBObject();
    
    
    public static MongoClient conectar(){
        MongoClient mongo=null;
        String server="localhost:27017";
        Integer puerto=27017;

        try {
            Logger.getLogger("org.mongodb.driver").setLevel(Level.WARNING);
            mongo=new MongoClient(server,puerto);
//            db=mongo.getDB("electrodomesticos");
//            tabla=db.getCollection("empleado");
   
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Error"+e.toString());
        }
        
        return mongo;
    }
    
}
