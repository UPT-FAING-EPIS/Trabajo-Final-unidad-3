/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Negocio;


import Entidad.ClsEEmpleado;
//import Entidad.ClsETrabajador;
import Presentacion.FrmLogin;
import javax.swing.JOptionPane;
import javax.swing.JOptionPane;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;


import com.mongodb.BasicDBObject;
import com.mongodb.DB;
import com.mongodb.DBCollection;
import com.mongodb.DBCursor;
import com.mongodb.MongoClient;
/**
 *
 * @author Arnold
 */
public class ClsNEmpleado {
    public DB db;
    public DBCollection tabla;
    public DBCursor cursor;
    
    
    MongoClient mongo=ClsConexionMongo.conectar();
    
    
    public DBCursor Listar(){
        
        db=mongo.getDB("electrodomesticos");
        tabla=db.getCollection("empleado");
        cursor=tabla.find();
        
        return cursor;
    }
    
    
    public boolean Insertar(ClsEEmpleado objEEmp){
        db=mongo.getDB("electrodomesticos");
        tabla=db.getCollection("empleado");
        
        BasicDBObject documento=new BasicDBObject();
        
        try {
            documento.put("dni", objEEmp.getDni());
            documento.put("nombre", objEEmp.getNombres());
            documento.put("apellido", objEEmp.getApellidos());
            documento.put("estado", objEEmp.getEstado());
            documento.put("clave", objEEmp.getClave());
            documento.put("Cargo_id", Integer. parseInt(objEEmp.getCargo()));
            tabla.insert(documento); 
            return true;
        } catch (Exception e) {
            return false;
        }
    }
    
    public DBCursor Buscar(ClsEEmpleado objEC){
        db=mongo.getDB("electrodomesticos");
        tabla=db.getCollection("empleado");
        
        BasicDBObject documento=new BasicDBObject();
        documento.put("dni",objEC.getDni());

        cursor=tabla.find(documento);
        return cursor;
    }
    
    
    public Boolean Eliminar(ClsEEmpleado objEEmp){
        db=mongo.getDB("electrodomesticos");
        tabla=db.getCollection("empleado");
        
        BasicDBObject documento=new BasicDBObject();
        try {
            documento.put("dni", objEEmp.getDni());
            tabla.remove(documento);
            return true;
        } catch (Exception e) {
            return false;
        }
    }
    
    
    public Boolean ActualizarEstado(ClsEEmpleado objEEmp){
        db=mongo.getDB("electrodomesticos");
        tabla=db.getCollection("empleado");
        
        BasicDBObject actualizar=new BasicDBObject();
        actualizar.append("$set", new BasicDBObject().append("estado",objEEmp.getEstado()));
        
        BasicDBObject buscar=new BasicDBObject();
        buscar.append("dni", objEEmp.getDni());

        try {
            tabla.update(buscar, actualizar);
            return true;
        } catch (Exception e) {
            return false;
        }
    }
    
    
    
    
    
    
    public ResultSet MtdListar_Empleados() {
        PreparedStatement ps=null;
        ResultSet rs=null;
        Connection con=(Connection) ClsConexion.Conectar();
        String sql="SELECT * from empleado;";
        try
        {
            ps=con.prepareStatement(sql);                        
            rs=ps.executeQuery();            
            return rs;
        }            
        catch (Exception e)
        {
           rs=null;
           return rs;
        }
    }
    
    public void MtdEliminar(int a) {
        PreparedStatement ps=null;
        ResultSet rs=null;
        Connection con=(Connection) ClsConexion.Conectar();
        String sql="delete from empleado where dni=?;";
        try
        {
            ps=con.prepareStatement(sql); 
            ps.setInt(1,a);
            ps.executeUpdate();
        }            
        catch (Exception e)
        {
            System.out.println(e);
           
        }
    }
    
    public void MtdEstado(String estado, int dni) {
        PreparedStatement ps=null;
        ResultSet rs=null;
        Connection con=(Connection) ClsConexion.Conectar();
        String sql="update empleado set estado=? where dni=?; ";
        try
        {
            ps=con.prepareStatement(sql);
            ps.setString(1,estado);
            ps.setInt(2,dni);            
            ps.executeUpdate();//permite actualizar 
            
        }            
        catch (Exception e)
        {
            System.out.println(e);
           
        }
    } 
    
    public ResultSet MtdBuscar(ClsEEmpleado objEEmp) {
        PreparedStatement ps=null;
        ResultSet rs=null;
        Connection con=(Connection) ClsConexion.Conectar();
        String sql="SELECT * from empleado where dni=?;";
        try
        {
            ps=con.prepareStatement(sql); 
            ps.setInt(1,Integer.parseInt(objEEmp.getB()));
            rs=ps.executeQuery();   
            return rs;
            
        }            
        catch (Exception e)
        {
           rs=null;
           return rs;
           
        }
    }
    
    public boolean MtdRegistrarEmpleado(ClsEEmpleado objEEmp) {
      PreparedStatement ps=null;      
      Connection con=(Connection) ClsConexion.Conectar();
      String sql="Insert into empleado (dni,nombres,apellidos,cargo,estado,clave) values(?,?,?,?,?,?); ";
            try {
            ps=con.prepareStatement(sql);
            ps.setString(1,objEEmp.getDni());
            ps.setString(2,objEEmp.getNombres());
            ps.setString(3,objEEmp.getApellidos());
            ps.setString(4,objEEmp.getCargo()); 
            ps.setString(5,objEEmp.getEstado()); 
            ps.setString(6,objEEmp.getClave()); 
            ps.executeUpdate();//permite actualizar 
            return true;
            }            
         catch (Exception e) {
            return false;
        }
    
    }
    
    
    public ResultSet MtdBuscar1(ClsEEmpleado objEEmp) {
        PreparedStatement ps=null;
        ResultSet rs=null;
        Connection con=(Connection) ClsConexion.Conectar();
        String sql="SELECT * from empleado where nombres=?;";
        try
        {
            ps=con.prepareStatement(sql); 
            ps.setString(1,objEEmp.getB());
            rs=ps.executeQuery();   
            return rs;
            
        }            
        catch (Exception e)
        {
           rs=null;
           return rs;
           
        }
    }
    
    public ResultSet MtdBuscar2(ClsEEmpleado objEEmp) {
        PreparedStatement ps=null;
        ResultSet rs=null;
        Connection con=(Connection) ClsConexion.Conectar();
        String sql="SELECT * from empleado where apellidos=?;";
        try
        {
            ps=con.prepareStatement(sql); 
            ps.setString(1,objEEmp.getB());
            rs=ps.executeQuery();   
            return rs;
            
        }            
        catch (Exception e)
        {
           rs=null;
           return rs;
           
        }
    }
    
    public ResultSet MtdBuscar3(ClsEEmpleado objEEmp) {
        PreparedStatement ps=null;
        ResultSet rs=null;
        Connection con=(Connection) ClsConexion.Conectar();
        String sql="SELECT * from empleado where cargo=?;";
        try
        {
            ps=con.prepareStatement(sql); 
            ps.setString(1,objEEmp.getB());
            rs=ps.executeQuery();   
            return rs;
            
        }            
        catch (Exception e)
        {
           rs=null;
           return rs;
           
        }
    }
    
    public ResultSet MtdBuscar4(ClsEEmpleado objEEmp) {
        PreparedStatement ps=null;
        ResultSet rs=null;
        Connection con=(Connection) ClsConexion.Conectar();
        String sql="SELECT * from empleado where estado=?;";
        try
        {
            ps=con.prepareStatement(sql); 
            ps.setString(1,objEEmp.getB());
            rs=ps.executeQuery();   
            return rs;
            
        }            
        catch (Exception e)
        {
           rs=null;
           return rs;
           
        }
    }
    
    public ResultSet MtdBuscar5(ClsEEmpleado objEEmp) {
        PreparedStatement ps=null;
        ResultSet rs=null;
        Connection con=(Connection) ClsConexion.Conectar();
        String sql="SELECT * from empleado where clave=?;";
        try
        {
            ps=con.prepareStatement(sql); 
            ps.setString(1,objEEmp.getB());
            rs=ps.executeQuery();   
            return rs;
            
        }            
        catch (Exception e)
        {
           rs=null;
           return rs;
           
        }
    }
    
    
    
    
    
}
