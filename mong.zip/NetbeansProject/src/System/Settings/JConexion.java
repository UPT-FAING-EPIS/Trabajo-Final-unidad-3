/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package System.Settings;

/**
 *
 * @author nekszer
 */
public class JConexion {
    
    /**
     * Version del API
     */
    public static final String version = "1.4.2";
    
    /**
     * Nombre del API
     */
    public static final String nombre = "JConexionDB";
    
    /**
     * Nombre del desarrollador
     */
    public static final String developer = "Nekszer";
    
    /**
     * 
     */
    public static final String company = "Developers Azteca";
    /**
     * Nombre y version del API
     */
    public static final String informacion = nombre + " " + version;
    
    
}
